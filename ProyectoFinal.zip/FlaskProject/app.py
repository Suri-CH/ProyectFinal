from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Lista global para almacenar las tareas
tasks = []

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Recibir datos del formulario
        task_name = request.form['taskName']
        task_duration = request.form['taskDuration']
        task_priority = request.form['taskPriority']

        # Agregar la tarea a la lista
        tasks.append({
            'name': task_name,
            'duration': task_duration,
            'priority': task_priority
        })

        return redirect(url_for('index'))  # Redirigir a la misma página después de agregar la tarea

    # Si es un GET, mostrar la página con las tareas
    return render_template('index.html', tasks=tasks)

@app.route('/delete/<int:task_index>', methods=['GET'])
def delete_task(task_index):
    # Eliminar la tarea de la lista por índice
    if 0 <= task_index < len(tasks):
        tasks.pop(task_index)
    return redirect(url_for('index'))  # Redirigir a la lista actualizada

if __name__ == '__main__':
    app.run(debug=True)
